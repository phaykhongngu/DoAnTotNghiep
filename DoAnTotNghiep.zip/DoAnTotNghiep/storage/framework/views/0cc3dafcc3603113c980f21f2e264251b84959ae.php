<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layout.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layout.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="loading">
    <h1 class="hidden-seoh">HL GROUP</h1>
    <?php echo $__env->make('layout.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layout.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layout.mmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layout.slide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php 
        $homeurl = '/';
        $currentpage = $_SERVER['REQUEST_URI'];
    ?>
    <?php if ( ($currentpage == $homeurl)) { ?>
         <?php echo $__env->make('index.index_tpl', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php } ?>

    <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layout.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>