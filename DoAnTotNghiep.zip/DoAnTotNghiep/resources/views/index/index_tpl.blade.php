<div class="spnb-main">
    <div class="mycontainer">
        <div class="title-main">
            <h2>Sản phẩm nổi bật</h2>
        </div>
        <div class="owl-carousel owl-themes owl-spnb">
            <div class="product-item">
                <div class="image-box">
                    <img src="/images/sanpham-item.png">
                </div>
                <div class="box-desc">
                    <div class="color-row d-flex">
                        <div class="watermark"><p>HL GROUP® <span>MEN</span></p></div>
                        <div class="colour-box d-flex">
                            <div class="colour-item">
                                <img src="/images/Grey.jpg">
                            </div>
                            <div class="colour-item">
                                <img src="/images/Grey.jpg">
                            </div>
                        </div>
                    </div>
                    <h3 class="product-title text-split1">Shark Full Zip Hoodie Keychain</h3>
                    <p class="new-price">1,000,000VNĐ</p>
                </div>
            </div>
            <div class="product-item">
                <div class="image-box">
                    <img src="/images/sanpham-item.png">
                </div>
                <div class="box-desc">
                    <div class="color-row d-flex">
                        <div class="watermark"><p>HL GROUP® <span>MEN</span></p></div>
                        <div class="colour-box d-flex">
                            <div class="colour-item">
                                <img src="/images/Grey.jpg">
                            </div>
                            <div class="colour-item">
                                <img src="/images/Grey.jpg">
                            </div>
                        </div>
                    </div>
                    <h3 class="product-title text-split1">Shark Full Zip Hoodie Keychain</h3>
                    <p class="new-price">1,000,000VNĐ</p>
                </div>
            </div>
            <div class="product-item">
                <div class="image-box">
                    <img src="/images/sanpham-item.png">
                </div>
                <div class="box-desc">
                    <div class="color-row d-flex">
                        <div class="watermark"><p>HL GROUP® <span>MEN</span></p></div>
                        <div class="colour-box d-flex">
                            <div class="colour-item">
                                <img src="/images/Grey.jpg">
                            </div>
                            <div class="colour-item">
                                <img src="/images/Grey.jpg">
                            </div>
                        </div>
                    </div>
                    <h3 class="product-title text-split1">Shark Full Zip Hoodie Keychain</h3>
                    <p class="new-price">1,000,000VNĐ</p>
                </div>
            </div>
            <div class="product-item">
                <div class="image-box">
                    <img src="/images/sanpham-item.png">
                </div>
                <div class="box-desc">
                    <div class="color-row d-flex">
                        <div class="watermark"><p>HL GROUP® <span>MEN</span></p></div>
                        <div class="colour-box d-flex">
                            <div class="colour-item">
                                <img src="/images/Grey.jpg">
                            </div>
                            <div class="colour-item">
                                <img src="/images/Grey.jpg">
                            </div>
                        </div>
                    </div>
                    <h3 class="product-title text-split1">Shark Full Zip Hoodie Keychain</h3>
                    <p class="new-price">1,000,000VNĐ</p>
                </div>
            </div>
            <div class="product-item">
                <div class="image-box">
                    <img src="/images/sanpham-item.png">
                </div>
                <div class="box-desc">
                    <div class="color-row d-flex">
                        <div class="watermark"><p>HL GROUP® <span>MEN</span></p></div>
                        <div class="colour-box d-flex">
                            <div class="colour-item">
                                <img src="/images/Grey.jpg">
                            </div>
                            <div class="colour-item">
                                <img src="/images/Grey.jpg">
                            </div>
                        </div>
                    </div>
                    <h3 class="product-title text-split1">Shark Full Zip Hoodie Keychain</h3>
                    <p class="new-price">1,000,000VNĐ</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="banner-main">
    <div class="banner-row d-flex flex-wrap">
        <div class="banner-item col-xl-6 col-12">
            <img src="/images/banner.png" alt="banner.png">
        </div>
        <div class="banner-item col-xl-6 col-12">
            <img src="/images/banner2.png" alt="banner2.png">
        </div>
    </div>
</div>

<div class="album-main">
    <div class="mycontainer">
        <div class="owl-carousel owl-themes owl-album">
            <div class="album-item">
                <div class="album-box">
                    <img src="/images/album1.png">
                </div>
                <div class="text-box">
                    <p>Shop</p>
                    <h3>NAM</h3>
                </div>
            </div>
            <div class="album-item">
                <div class="album-box">
                    <img src="/images/album2.png">
                </div>
                <div class="text-box">
                    <p>Shop</p>
                    <h3>NỮ</h3>
                </div>
            </div>
            <div class="album-item">
                <div class="album-box">
                    <img src="/images/album3.png">
                </div>
                <div class="text-box">
                    <p>Shop</p>
                    <h3>TRẺ EM</h3>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="brand-main">
    <div class="mycontainer">
        <div class="title-main">
            <h2>Thương hiệu</h2>
        </div>
        <div class="owl-carousel owl-themes owl-brand">
            <div class="brand-item">
                <img src="/images/brand-img1.jpg">
            </div>
            <div class="brand-item">
                <img src="/images/brand-img2.jpg">
            </div>
            <div class="brand-item">
                <img src="/images/brand-img3.jpg">
            </div>
            <div class="brand-item">
                <img src="/images/brand-img4.jpg">
            </div>
            <div class="brand-item">
                <img src="/images/brand-img5.jpg">
            </div>
            <div class="brand-item">
                <img src="/images/brand-img1.jpg">
            </div>
        </div>
    </div>
</div>