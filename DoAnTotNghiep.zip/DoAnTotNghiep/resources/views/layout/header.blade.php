<div class="header-main">
    <div class="mycontainer">
        <div class="header-row d-flex flex-wrap">
            <div class="header-row__left d-flex">
                <img src="/images/global-icon.png" alt="global-icon.png">
                <p class="header-row__left--text">MIỄN PHÍ VẬN CHUYỂN ĐƠN HÀNG TRÊN 5.000.000VNĐ</p>
            </div>
            <div class="header-row__right">
                <p>KHÁM PHÁ NHIỀU HƠN &#8628;</p>
            </div>
        </div>
    </div>
</div>