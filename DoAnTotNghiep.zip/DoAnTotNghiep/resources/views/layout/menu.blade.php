<div class="menu-main">
    <div class="mycontainer">
        <div class="menu-row d-flex flex-wrap">
            <div class="menu-row__left">
                <ul class="menu-parent d-flex">
                    <li class="menu-child">
                        <a href="#">Nam</a>
                        <div id="menu-pc">
                            <div class="mycontainer">
                                <div class="nav-menu-row d-flex">
                                    <div class="col-3">
                                        <ul>
                                            <li>Test 1</li>
                                            <li>Test 2</li>
                                            <li>Test 3</li>
                                            <li>Test 4</li>
                                            <li>Test 5</li>
                                        </ul>
                                    </div>
                                    <div class="col-3">
                                        <ul>
                                            <li>Test 1</li>
                                            <li>Test 2</li>
                                            <li>Test 3</li>
                                            <li>Test 4</li>
                                            <li>Test 5</li>
                                        </ul>
                                    </div>
                                    <div class="col-3">
                                        <ul>
                                            <li>Test 1</li>
                                            <li>Test 2</li>
                                            <li>Test 3</li>
                                            <li>Test 4</li>
                                            <li>Test 5</li>
                                        </ul>
                                    </div>
                                    <div class="col-3">
                                        <ul>
                                            <li>Test 1</li>
                                            <li>Test 2</li>
                                            <li>Test 3</li>
                                            <li>Test 4</li>
                                            <li>Test 5</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="menu-child">
                        <a href="#">Nữ</a>
                        <div id="menu-pc">
                            <div class="mycontainer">
                                <div class="nav-menu-row d-flex">
                                    <div class="col-3">
                                        <ul>
                                            <li>Test 1</li>
                                            <li>Test 2</li>
                                            <li>Test 3</li>
                                            <li>Test 4</li>
                                            <li>Test 5</li>
                                        </ul>
                                    </div>
                                    <div class="col-3">
                                        <ul>
                                            <li>Test 1</li>
                                            <li>Test 2</li>
                                            <li>Test 3</li>
                                            <li>Test 4</li>
                                            <li>Test 5</li>
                                        </ul>
                                    </div>
                                    <div class="col-3">
                                        <ul>
                                            <li>Test 1</li>
                                            <li>Test 2</li>
                                            <li>Test 3</li>
                                            <li>Test 4</li>
                                            <li>Test 5</li>
                                        </ul>
                                    </div>
                                    <div class="col-3">
                                        <ul>
                                            <li>Test 1</li>
                                            <li>Test 2</li>
                                            <li>Test 3</li>
                                            <li>Test 4</li>
                                            <li>Test 5</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="menu-child">
                        <a href="#">Trẻ em</a>
                        <div id="menu-pc">
                            <div class="mycontainer">
                                <div class="nav-menu-row d-flex">
                                    <div class="col-3">
                                        <ul>
                                            <li>Test 1</li>
                                            <li>Test 2</li>
                                            <li>Test 3</li>
                                            <li>Test 4</li>
                                            <li>Test 5</li>
                                        </ul>
                                    </div>
                                    <div class="col-3">
                                        <ul>
                                            <li>Test 1</li>
                                            <li>Test 2</li>
                                            <li>Test 3</li>
                                            <li>Test 4</li>
                                            <li>Test 5</li>
                                        </ul>
                                    </div>
                                    <div class="col-3">
                                        <ul>
                                            <li>Test 1</li>
                                            <li>Test 2</li>
                                            <li>Test 3</li>
                                            <li>Test 4</li>
                                            <li>Test 5</li>
                                        </ul>
                                    </div>
                                    <div class="col-3">
                                        <ul>
                                            <li>Test 1</li>
                                            <li>Test 2</li>
                                            <li>Test 3</li>
                                            <li>Test 4</li>
                                            <li>Test 5</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li><a href="#">Tin tức</a></li>
                    <li><a href="#">Bộ sưu tập</a></li>
                </ul>
            </div>
            <div class="menu-row__right d-flex">
                <ul class="menu-parent d-flex">
                    <li><a href="#">Chi nhánh</a></li>
                    <li><a href="#">Tìm kiếm</a></li>
                    <li><a href="#">Yêu thích</a></li>
                    <li><a href="#">Tài khoản</a></li>
                    <li class="giohang"><a href="#">Giỏ hàng</a></li>
                </ul>
                <p class="giohang-text">1</p>
            </div>
        </div>
        <div class="menu-row__logo">
            <a href="">
                <img src="/images/logo.png" alt="logo.png">
            </a>
        </div>
    </div>
</div>