<div class="footer">
    <div class="footer-top">
        <div class="mycontainer">
            <div class="footer-row d-flex flex-wrap">
                <div class="footer-social-box">
                    <div class="image-box">
                        <img src="/images/logo-footer.png" alt="logo-footer.png">
                    </div>
                    <div class="social-list d-flex">
                        <a href="https://www.facebook.com/Phasy.Z01">
                            <i class="fab fa-facebook-square"></i>
                        </a>
                        <a href="https://www.twitter.com/">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="https://www.instagram.com/">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </div>
                </div>
                <div class="footer-shop-box">
                    <h3 class="footer-title">SHOP</h3>
                    <ul class="footer-ul">
                        <li><a href="#" title="Nam">Nam</a></li>
                        <li><a href="#" title="Nữ">Nữ</a></li>
                        <li><a href="#" title="Trẻ em">Trẻ em</a></li>
                    </ul>
                </div>
                <div class="footer-findout-box">
                    <h3 class="footer-title">EXPLORE</h3>
                    <ul class="footer-ul">
                        <li><a href="#" title="Tin tức">Tin tức</a></li>
                        <li><a href="#" title="Bộ sưu tập">Bộ sưu tập</a></li>
                    </ul>
                </div>
                <div class="footer-support-box">
                    <h3 class="footer-title">SUPPORT</h3>
                    <ul class="footer-ul">
                        <li><a href="#" title="Trung tâm trợ giúp">Trung tâm trợ giúp</a></li>
                        <li><a href="#" title="Liên hệ">Liên hệ</a></li>
                        <li><a href="#" title="Tài khoản">Tài khoản</a></li>
                        <li><a href="#" title="Cửa hàng">Cửa hàng</a></li>
                    </ul>
                </div>
                <div class="footer-dangky-box">
                    <h3 class="footer-title">KEEP IN TOUCH</h3>
                    <form>
                        <div class="contact-input col-sm-12">
                            <input type="email" class="form-control text-sm" id="email-contact" name="dataContact[email]" placeholder="Địa chỉ Email" required />
                        </div>
                        <div class="contact-button col-sm-12">
                            <input type="submit" class="submit-button" name="submit-contact" value="Theo dõi" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="mycontainer">
            <div class="footer-coppyright d-flex flex-wrap">
                <div class="footer-coppyright-text col-xl-6 col-12">
                    <p>© 2022 HL GROUP Limited</p>
                </div>
                <div class="footer-policy-text col-xl-6 col-12">
                    <ul>
                        <li><a href="#" title="chinh sach">Chính sách bảo mật</a></li>
                        <li><a href="#" title="chinh sach">Điều khoản sử dụng</a></li>
                        <li><a href="#" title="chinh sach">Chính sách cookie</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>