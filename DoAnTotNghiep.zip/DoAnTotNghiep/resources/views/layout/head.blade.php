<!-- Chống đổi màu trên IOS -->
<meta name="format-detection" content="telephone=no">

<!-- Viewport -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">

<link rel="icon" type="image/x-icon" href="/images/favicon.ico">
<title>HL GROUP®</title>