<!DOCTYPE html>
<html lang="en">
<head>
    @include ('layout.head')
    @include ('layout.css')
</head>
<body class="loading">
    <h1 class="hidden-seoh">HL GROUP</h1>
    @include ('layout.header')
    @include ('layout.menu')
    @include ('layout.mmenu')
    @include ('layout.slide')

    <?php 
        $homeurl = '/';
        $currentpage = $_SERVER['REQUEST_URI'];
    ?>
    <?php if ( ($currentpage == $homeurl)) { ?>
         @include ('index.index_tpl')
    <?php } ?>

    @include ('layout.footer')
    @include ('layout.js')
</body>
</html>