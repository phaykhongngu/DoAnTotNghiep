function isExist(ele)
{
    return ele.length;
}

OwlPage = function(){
    if($(".owl-spnb").length){
        {
            $('.owl-spnb').owlCarousel({
                rewind: true,
                autoplay: true,
                loop: false,
                lazyLoad: false,
                mouseDrag: true,
                touchDrag: true,
                margin: 5,
                smartSpeed: 250,
                autoplaySpeed: 1000,
                nav: false,
                dots: false,
                responsiveClass:true,
                responsiveRefreshRate: 200,
                responsive:{
                    0:{
                        items:1,
                    },
                    320:{
                        items:1,
                    },
                    375:{
                        items:2,
                    },
                    600:{
                        items:2,
                    },
                    800:{
                        items:3,
                    },
                    1100:{
                        items:4,
                    }
                }
            });
            $('.prev-blog_').click(function() {
                $('.owl-spnb').trigger('prev.owl.carousel');
            });
            $('.next-blog_').click(function() {
                $('.owl-spnb').trigger('next.owl.carousel');
            });
        }
    };

    if($(".owl-album").length){
        {
            $('.owl-album').owlCarousel({
                rewind: true,
                autoplay: true,
                loop: false,
                lazyLoad: false,
                mouseDrag: true,
                touchDrag: true,
                margin: 20,
                smartSpeed: 250,
                autoplaySpeed: 1000,
                nav: false,
                dots: false,
                responsiveClass:true,
                responsiveRefreshRate: 200,
                responsive:{
                    0:{
                        items:2,
                    },
                    320:{
                        items:2,
                    },
                    375:{
                        items:2,
                    },
                    600:{
                        items:2,
                    },
                    800:{
                        items:2,
                    },
                    1100:{
                        items:3,
                    }
                }
            });
            $('.prev-blog_').click(function() {
                $('.owl-album').trigger('prev.owl.carousel');
            });
            $('.next-blog_').click(function() {
                $('.owl-album').trigger('next.owl.carousel');
            });
        }
    };

    if($(".owl-brand").length){
        {
            $('.owl-brand').owlCarousel({
                rewind: true,
                autoplay: true,
                loop: false,
                lazyLoad: false,
                mouseDrag: true,
                touchDrag: true,
                margin: 20,
                smartSpeed: 250,
                autoplaySpeed: 1000,
                nav: false,
                dots: false,
                responsiveClass:true,
                responsiveRefreshRate: 200,
                responsive:{
                    0:{
                        items:2,
                    },
                    320:{
                        items:2,
                    },
                    375:{
                        items:2,
                    },
                    600:{
                        items:2,
                    },
                    800:{
                        items:3,
                    },
                    1100:{
                        items:5,
                    }
                }
            });
            $('.prev-blog_').click(function() {
                $('.owl-brand').trigger('prev.owl.carousel');
            });
            $('.next-blog_').click(function() {
                $('.owl-brand').trigger('next.owl.carousel');
            });
        }
    };
};

Menu = function(){
    /* Mmenu */
    if(isExist($("nav#menu")))
    {
        $('nav#menu').mmenu({
            "extensions": ["border-full", "position-left", "position-front"]
        });
    }
};

/* Search */
Search = function(){
    if(isExist($(".icon-search")))
    {
        $(".icon-search").click(function(){
            if($(this).hasClass('active'))
            {
                $(this).removeClass('active');
                $(".search-grid").stop(true,true).animate({opacity: "0",width: "0px"}, 200);   
            }
            else
            {
                $(this).addClass('active');                            
                $(".search-grid").stop(true,true).animate({opacity: "1",width: "230px"}, 200);
            }
            document.getElementById($(this).next().find("input").attr('id')).focus();
            $('.icon-search i').toggleClass('fa fa-search fa fa-times');
        });
    }
};

/* Ready */
$(document).ready(function(){
    OwlPage();
    Menu();
    Search();
    const loadimg = document.querySelectorAll("img");
    for (let i = 0; i < loadimg.length; i++) {
        if(i + 1 == loadimg.length) document.body.classList.remove('loading');
    }
});